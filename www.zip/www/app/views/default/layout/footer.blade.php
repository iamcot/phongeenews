<div id="footer" class="hidden-print">
    <div class="mycontainer wrap">
        <div class="subfooter">
        <div class="col-xs-12 col-md-4 hidden-xs hidden-sm">
            <div class="fb-like-box" data-href="https://www.facebook.com/phongee.vn" data-width="100%" data-colorscheme="dark" data-show-faces="true" data-header="false" data-stream="false" data-show-border="false"></div>
        </div>
        <div class="col-xs-12 col-md-4">
            <h2>About US</h2>
            <p>Something about us.</p>
        </div>
        <div class="col-xs-12 col-md-4">
            <h2>Get in touch</h2>
            <p>PhonGee 1: 12 Tôn Thất Tùng, Q1</p>
            <p>PhonGee 2: 12 Trần Quốc Hoàn, TB</p>
            <p>PhonGee 3: 2A Nguyễn Văn Đậu, BTh</p>
            <p>http://phongee.vn</p>
            <p>092 345 6789</p>
        </div>
    </div>


    </div>
    <div class="clearfix"></div>
    <div id="copyright" class="">
        &copy; {{date("Y")}} PhonGee. All rights reserved. Made with Passion.</a>

    </div>
</div>