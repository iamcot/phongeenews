<div id="start-store">
    <img src="{{URL::to('public/imagestore.png')}}">
    <div id="storetext">
        <p class="text-verybold">We love what we do & We do it with passion</p>
        <p class="text-light">We love what we do & We do it with passion<br>We love what we do & We do it with passion</p>
        <a id="visitstore" href="#">Visit our Store</a>
    </div>
</div>