@extends('layout')
@section('body')
<div id="cartpage" class="container-fluid">

    <div class="col-xs-12">
        <p class="bg404"></p>
        <div class="clearfix"></div>
        </div>
    </div>
@stop
