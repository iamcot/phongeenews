<?php
class Image extends Eloquent
{
    protected $table = 'laimages';
}