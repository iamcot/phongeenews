<?php
return array(
    'cart_has_new'=>11,
    'voucher_not_avail'=>21,
    'voucher_not_input'=>22,
    'voucher_expried'=>23,
);
