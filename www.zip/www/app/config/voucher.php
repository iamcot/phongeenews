<?php
return array(
    'online04' => array(
        'id' => 'online04',
        'type' => 'percent',
        'value' => 10,
        'to' => '2013-12-31 23:59:59',
    ),
    'online05' => array(
        'id' => 'online05',
        'type' => 'abs',
        'value' => 20000,
        'to' => '2014-12-31 23:59:59',
    ),
);