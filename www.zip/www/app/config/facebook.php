<?php
// app/config/facebook.php

// Facebook app Config
return array(
    'appId' => '753308934688020',
    'secret' => 'ae0a6680f2df7c293ff4ae296d5d7cea'
);