<?php
return array(
    '21' => 'Mã Voucher không tồn tại',
    '22' => 'Bạn chưa nhập voucher',
    '23' => 'Voucher này đã hết hạn sử dụng',
);