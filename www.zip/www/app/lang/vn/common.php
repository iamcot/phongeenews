<?php
return array(
    'LDHome'    =>  'Trang chủ',
    'LDOverview'    =>  'Tổng quan',
    'LDCat'     =>  'Thư mục',
    'LDProduct' =>  'Sản phẩm',
    'LDUser' =>  'Thành viên',
    'LDOrder'   =>  'Đơn hàng',
    'LDcreate'  =>  'Thêm / Sửa',
    'LDview'    =>  'Xem',
    'LDFactor'    =>  'Nhà Sản xuất',
    'LDSale'    =>  'Khuyến mãi',
    'LDConfig' => 'Cấu hình',
    'LDFanpage' => 'Fanpage',
    'LDComment' => 'Bình luận',
    'dang-hot' => 'Sản phẩm được mua và xem nhiều',
    'moi-ve' => 'Sản phẩm mới về',
    'dang-sale' => 'Sản phẩm đang có giá ưu đãi',
    'search' => 'Tìm kiếm',

);