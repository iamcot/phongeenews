# ************************************************************
# Sequel Pro SQL dump
# Version 4096
#
# http://www.sequelpro.com/
# http://code.google.com/p/sequel-pro/
#
# Host: 127.0.0.1 (MySQL 5.6.14)
# Database: phongeenews
# Generation Time: 2014-09-23 11:04:38 +0000
# ************************************************************


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


# Dump of table laorderaddress
# ------------------------------------------------------------

DROP TABLE IF EXISTS `laorderaddress`;

CREATE TABLE `laorderaddress` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `name` varchar(200) DEFAULT NULL,
  `sex` varchar(5) DEFAULT NULL,
  `tel` varchar(20) DEFAULT NULL,
  `address` varchar(200) DEFAULT NULL,
  `status` tinyint(4) DEFAULT '0',
  `updated_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `laorderaddress` WRITE;
/*!40000 ALTER TABLE `laorderaddress` DISABLE KEYS */;

INSERT INTO `laorderaddress` (`id`, `user_id`, `name`, `sex`, `tel`, `address`, `status`, `updated_at`, `created_at`)
VALUES
	(1,1,'Thang','m','0123456789','tan phu ho chi minh',0,'2014-09-23 15:43:54','2014-09-23 15:43:54'),
	(2,1,'Pepsi','f','0983717098','bmt',0,'2014-09-23 15:52:05','2014-09-23 15:52:05'),
	(3,1,'Coca','f','09123456789','tan phú, tây thạnh, hcm',0,'2014-09-23 15:57:36','2014-09-23 15:57:36');

/*!40000 ALTER TABLE `laorderaddress` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table laorders
# ------------------------------------------------------------

DROP TABLE IF EXISTS `laorders`;

CREATE TABLE `laorders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `lashipping` int(11) DEFAULT NULL,
  `labillid` int(11) DEFAULT NULL,
  `requireinvole` int(11) DEFAULT NULL,
  `lapayment` int(11) DEFAULT NULL,
  `lasumkhoiluong` int(11) DEFAULT NULL,
  `lafeeshipping` int(11) DEFAULT NULL,
  `laordername` text COLLATE utf8_unicode_ci,
  `laordertel` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `laorderemail` text COLLATE utf8_unicode_ci,
  `laorderaddr` text COLLATE utf8_unicode_ci,
  `laorderprovince` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `laorderdistrict` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `uid` bigint(20) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `order_status` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  `voucher` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `giamvoucher` int(11) DEFAULT NULL,
  `sumsanpham` int(11) DEFAULT NULL,
  `laordernote` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

LOCK TABLES `laorders` WRITE;
/*!40000 ALTER TABLE `laorders` DISABLE KEYS */;

INSERT INTO `laorders` (`id`, `lashipping`, `labillid`, `requireinvole`, `lapayment`, `lasumkhoiluong`, `lafeeshipping`, `laordername`, `laordertel`, `laorderemail`, `laorderaddr`, `laorderprovince`, `laorderdistrict`, `updated_at`, `created_at`, `uid`, `user_id`, `order_status`, `voucher`, `giamvoucher`, `sumsanpham`, `laordernote`)
VALUES
	(1,3,2,0,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2014-09-23 17:01:27','2014-09-23 17:01:27',NULL,1,'0','',NULL,NULL,''),
	(2,3,2,0,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2014-09-23 17:52:28','2014-09-23 17:52:28',NULL,1,'0','online05',20000,24800000,'');

/*!40000 ALTER TABLE `laorders` ENABLE KEYS */;
UNLOCK TABLES;



/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
