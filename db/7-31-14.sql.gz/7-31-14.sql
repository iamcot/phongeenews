# ************************************************************
# Sequel Pro SQL dump
# Version 4096
#
# http://www.sequelpro.com/
# http://code.google.com/p/sequel-pro/
#
# Host: 127.0.0.1 (MySQL 5.6.19)
# Database: phongeenews
# Generation Time: 2014-07-31 13:17:08 +0000
# ************************************************************


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


# Dump of table lacategories
# ------------------------------------------------------------

DROP TABLE IF EXISTS `lacategories`;

CREATE TABLE `lacategories` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `latitle` varchar(50) DEFAULT NULL,
  `laparent_id` int(11) DEFAULT NULL,
  `laurl` varchar(50) DEFAULT NULL,
  `lainfo` text,
  `ladeleted` int(11) NOT NULL DEFAULT '0',
  `laorder` int(11) DEFAULT NULL,
  `laimage` varchar(50) DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `laicon` varchar(100) NOT NULL DEFAULT 'glyphicon glyphicon-link',
  `isnews` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `url` (`laurl`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `lacategories` WRITE;
/*!40000 ALTER TABLE `lacategories` DISABLE KEYS */;

INSERT INTO `lacategories` (`id`, `latitle`, `laparent_id`, `laurl`, `lainfo`, `ladeleted`, `laorder`, `laimage`, `updated_at`, `created_at`, `laicon`, `isnews`)
VALUES
	(1,'Apple',0,'apple','Đẳng cấp của bạn.',0,1,NULL,'2014-06-06 10:30:32','2014-06-04 14:21:24','glyphicon glyphicon-link',0),
	(2,'Hãng khác',0,'hang-khac','',0,2,NULL,'2014-06-04 14:21:39','2014-06-04 14:21:39','glyphicon glyphicon-link',0),
	(3,'iPhone',1,'iphone','',0,0,'tO0Jt0aW1DotD4Tya6ifXEslCIm1buAc.jpg','2014-06-06 10:56:16','2014-06-04 14:22:00','glyphicon glyphicon-link',0),
	(4,'iPad',1,'ipad','',0,0,'S85nbAnPygMFGjeoNmU9r7oERyxPGHeR.jpg','2014-06-06 10:56:08','2014-06-04 14:22:10','glyphicon glyphicon-link',0),
	(5,'Samsung',2,'samsung','',0,0,NULL,'2014-06-04 14:22:26','2014-06-04 14:22:26','glyphicon glyphicon-link',0),
	(6,'HTC',2,'htc','',0,0,NULL,'2014-06-04 14:22:36','2014-06-04 14:22:36','glyphicon glyphicon-link',0),
	(7,'Tin tức',0,'tin-tuc','',0,7,NULL,'2014-06-06 18:04:19','2014-06-04 15:31:11','glyphicon glyphicon-link',1),
	(8,'Tin khuyến mãi',7,'tin-khuyen-mai','',0,0,NULL,'2014-06-04 17:49:03','2014-06-04 15:31:27','glyphicon glyphicon-link',1),
	(9,'Tin công ty',7,'tin-cong-ty','',0,0,NULL,'2014-06-04 17:49:07','2014-06-04 15:31:32','glyphicon glyphicon-link',1),
	(10,'Tin báo chí',7,'tin-bao-chi','',0,0,NULL,'2014-06-04 17:49:11','2014-06-04 15:32:37','glyphicon glyphicon-link',1),
	(11,'Kho máy cũ',0,'kho-may-cu','',0,3,NULL,'2014-06-04 15:33:30','2014-06-04 15:33:24','glyphicon glyphicon-link',0),
	(12,'Tin nổi bật',7,'tin-noi-bat','',0,0,NULL,'2014-06-04 17:49:15','2014-06-04 15:35:09','glyphicon glyphicon-link',1),
	(13,'Phụ kiện',0,'phu-kien','',0,5,NULL,'2014-06-06 18:04:07','2014-06-06 18:04:07','glyphicon glyphicon-link',0),
	(14,'Bảo hành',0,'bao-hanh','',0,6,NULL,'2014-06-11 11:47:32','2014-06-11 11:47:32','glyphicon glyphicon-link',0),
	(15,'Chi nhánh',0,'chi-nhanh','',0,7,NULL,'2014-06-11 11:47:44','2014-06-11 11:47:44','glyphicon glyphicon-link',0),
	(16,'iPhone 2',1,'iphone2','',0,0,'tO0Jt0aW1DotD4Tya6ifXEslCIm1buAc.jpg','2014-06-06 10:56:16','2014-06-04 14:22:00','glyphicon glyphicon-link',0),
	(17,'iPhone 3',1,'iphone 3','',0,0,'tO0Jt0aW1DotD4Tya6ifXEslCIm1buAc.jpg','2014-06-06 10:56:16','2014-06-04 14:22:00','glyphicon glyphicon-link',0),
	(18,'iPhone  4',1,'iphone4 ','',0,0,'tO0Jt0aW1DotD4Tya6ifXEslCIm1buAc.jpg','2014-06-06 10:56:16','2014-06-04 14:22:00','glyphicon glyphicon-link',0),
	(19,'iPhone 5',1,'iphone5','',0,0,'tO0Jt0aW1DotD4Tya6ifXEslCIm1buAc.jpg','2014-06-06 10:56:16','2014-06-04 14:22:00','glyphicon glyphicon-link',0);

/*!40000 ALTER TABLE `lacategories` ENABLE KEYS */;
UNLOCK TABLES;



/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
