# ************************************************************
# Sequel Pro SQL dump
# Version 4096
#
# http://www.sequelpro.com/
# http://code.google.com/p/sequel-pro/
#
# Host: daklaksaigon.com (MySQL 5.5.32-cll-lve)
# Database: daklaksa_phongeenews
# Generation Time: 2014-07-31 06:02:12 +0000
# ************************************************************


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


# Dump of table facebookuser
# ------------------------------------------------------------

DROP TABLE IF EXISTS `facebookuser`;

CREATE TABLE `facebookuser` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `facebookname` text,
  `facebookid` varchar(50) DEFAULT NULL,
  `gender` varchar(10) DEFAULT NULL,
  `locale` varchar(20) DEFAULT NULL,
  `username` varchar(50) DEFAULT NULL,
  `fanpage_id` varchar(50) DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table fanpage
# ------------------------------------------------------------

DROP TABLE IF EXISTS `fanpage`;

CREATE TABLE `fanpage` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `pageid` varchar(50) DEFAULT NULL,
  `pageusername` varchar(50) DEFAULT NULL,
  `pagename` varchar(50) DEFAULT NULL,
  `likes` int(11) DEFAULT NULL,
  `category` varchar(50) DEFAULT NULL,
  `about` text,
  `updated_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table lacategories
# ------------------------------------------------------------

DROP TABLE IF EXISTS `lacategories`;

CREATE TABLE `lacategories` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `latitle` varchar(50) DEFAULT NULL,
  `laparent_id` int(11) DEFAULT NULL,
  `laurl` varchar(50) DEFAULT NULL,
  `lainfo` text,
  `ladeleted` int(11) NOT NULL DEFAULT '0',
  `laorder` int(11) DEFAULT NULL,
  `laimage` varchar(50) DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `laicon` varchar(100) NOT NULL DEFAULT 'glyphicon glyphicon-link',
  `isnews` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `url` (`laurl`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `lacategories` WRITE;
/*!40000 ALTER TABLE `lacategories` DISABLE KEYS */;

INSERT INTO `lacategories` (`id`, `latitle`, `laparent_id`, `laurl`, `lainfo`, `ladeleted`, `laorder`, `laimage`, `updated_at`, `created_at`, `laicon`, `isnews`)
VALUES
	(1,'Apple',0,'apple','Đẳng cấp của bạn.',0,1,NULL,'2014-06-06 10:30:32','2014-06-04 14:21:24','glyphicon glyphicon-link',0),
	(2,'Hãng khác',0,'hang-khac','',0,2,NULL,'2014-06-04 14:21:39','2014-06-04 14:21:39','glyphicon glyphicon-link',0),
	(3,'iPhone',1,'iphone','',0,0,'tO0Jt0aW1DotD4Tya6ifXEslCIm1buAc.jpg','2014-06-06 10:56:16','2014-06-04 14:22:00','glyphicon glyphicon-link',0),
	(4,'iPad',1,'ipad','',0,0,'S85nbAnPygMFGjeoNmU9r7oERyxPGHeR.jpg','2014-06-06 10:56:08','2014-06-04 14:22:10','glyphicon glyphicon-link',0),
	(5,'Samsung',2,'samsung','',0,0,NULL,'2014-06-04 14:22:26','2014-06-04 14:22:26','glyphicon glyphicon-link',0),
	(6,'HTC',2,'htc','',0,0,NULL,'2014-06-04 14:22:36','2014-06-04 14:22:36','glyphicon glyphicon-link',0),
	(7,'Tin tức',0,'tin-tuc','',0,7,NULL,'2014-06-06 18:04:19','2014-06-04 15:31:11','glyphicon glyphicon-link',1),
	(8,'Tin khuyến mãi',7,'tin-khuyen-mai','',0,0,NULL,'2014-06-04 17:49:03','2014-06-04 15:31:27','glyphicon glyphicon-link',1),
	(9,'Tin công ty',7,'tin-cong-ty','',0,0,NULL,'2014-06-04 17:49:07','2014-06-04 15:31:32','glyphicon glyphicon-link',1),
	(10,'Tin báo chí',7,'tin-bao-chi','',0,0,NULL,'2014-06-04 17:49:11','2014-06-04 15:32:37','glyphicon glyphicon-link',1),
	(11,'Kho máy cũ',0,'kho-may-cu','',0,3,NULL,'2014-06-04 15:33:30','2014-06-04 15:33:24','glyphicon glyphicon-link',0),
	(12,'Tin nổi bật',7,'tin-noi-bat','',0,0,NULL,'2014-06-04 17:49:15','2014-06-04 15:35:09','glyphicon glyphicon-link',1),
	(13,'Phụ kiện',0,'phu-kien','',0,5,NULL,'2014-06-06 18:04:07','2014-06-06 18:04:07','glyphicon glyphicon-link',0),
	(14,'Bảo hành',0,'bao-hanh','',0,6,NULL,'2014-06-11 11:47:32','2014-06-11 11:47:32','glyphicon glyphicon-link',0),
	(15,'Chi nhánh',0,'chi-nhanh','',0,7,NULL,'2014-06-11 11:47:44','2014-06-11 11:47:44','glyphicon glyphicon-link',0);

/*!40000 ALTER TABLE `lacategories` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table laconfig
# ------------------------------------------------------------

DROP TABLE IF EXISTS `laconfig`;

CREATE TABLE `laconfig` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `lavar` varchar(20) DEFAULT NULL,
  `lavalue` text,
  `updated_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

LOCK TABLES `laconfig` WRITE;
/*!40000 ALTER TABLE `laconfig` DISABLE KEYS */;

INSERT INTO `laconfig` (`id`, `lavar`, `lavalue`, `updated_at`, `created_at`)
VALUES
	(1,'slide','zcqwItJHgcZmtAPysGXtsIptTLhR5VWK.png||#\r\ntv5eOqyYUvoCJOHTdp1n9Fe6OJyUhmQi.png||#\r\n37RoAG0mbN3QyFRjVWc3nTtSaawGDTqu.png||#\r\nVOs1eyH83RUPZd0TKyH9BS4IJtiKIkoM.png||#\r\nsV3FGU9rG4LLDq7IXNToXYJUM6zuOJbu.png||#','2014-06-11 12:13:11','2014-06-04 15:25:46'),
	(2,'sidebarads','','2014-06-04 15:25:46','2014-06-04 15:25:46');

/*!40000 ALTER TABLE `laconfig` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table lafacebookcomments
# ------------------------------------------------------------

DROP TABLE IF EXISTS `lafacebookcomments`;

CREATE TABLE `lafacebookcomments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `lafullname` text,
  `lacontent` text,
  `laurl` text,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `lafacebookcomments` WRITE;
/*!40000 ALTER TABLE `lafacebookcomments` DISABLE KEYS */;

INSERT INTO `lafacebookcomments` (`id`, `lafullname`, `lacontent`, `laurl`, `updated_at`, `created_at`)
VALUES
	(1,NULL,NULL,NULL,'2014-06-20 04:38:53','2014-06-20 04:38:53');

/*!40000 ALTER TABLE `lafacebookcomments` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table lafacebookprofiles
# ------------------------------------------------------------

DROP TABLE IF EXISTS `lafacebookprofiles`;

CREATE TABLE `lafacebookprofiles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned DEFAULT NULL,
  `username` text CHARACTER SET latin1,
  `uid` bigint(20) unsigned DEFAULT NULL,
  `laaccess_token` text CHARACTER SET latin1,
  `laaccess_token_secret` text CHARACTER SET latin1,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table laimages
# ------------------------------------------------------------

DROP TABLE IF EXISTS `laimages`;

CREATE TABLE `laimages` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `lapic` varchar(50) DEFAULT NULL,
  `latitle` varchar(100) DEFAULT NULL,
  `laproduct_id` int(11) DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `laimages` WRITE;
/*!40000 ALTER TABLE `laimages` DISABLE KEYS */;

INSERT INTO `laimages` (`id`, `lapic`, `latitle`, `laproduct_id`, `updated_at`, `created_at`)
VALUES
	(5,'W32Z1e4FzNREcZc2y3isgNZBslcvXJsv.png','',2,'2014-06-06 23:41:28','2014-06-06 23:41:28'),
	(6,'D4pKkC5qz3EaneohRj62RKtp4mB2IXUd.png','',3,'2014-06-06 23:50:07','2014-06-06 23:50:07'),
	(7,'xl5gp3h6Kf8PrQp83sCisbOkJhj5IJVV.png','',4,'2014-06-06 23:50:44','2014-06-06 23:50:44'),
	(8,'L0aZq7OHKSg56SFrtQpynFpH9U2naCWr.png','',4,'2014-06-06 23:50:44','2014-06-06 23:50:44'),
	(9,'AJCT8ggXaCJtll8HkhCHL0vrCO9YpM6V.png','',5,'2014-06-06 23:51:11','2014-06-06 23:51:11'),
	(10,'LyWSOsF8eYYwPqkA3NJDOjZtP2QNNOmY.png','',5,'2014-06-06 23:51:11','2014-06-06 23:51:11'),
	(11,'qtTsHL2Z5FeRC0fLgD35paA5p0I3O53Y.png','',6,'2014-06-06 23:52:20','2014-06-06 23:52:20'),
	(12,'mvD78zfehvY2KukneK3aVvhg8o9z5WKU.png','',6,'2014-06-06 23:52:20','2014-06-06 23:52:20'),
	(13,'93B8ko9arNBj5GTlAWDj6EZvua8fl7Y3.png','',7,'2014-06-07 00:10:39','2014-06-07 00:10:39'),
	(14,'RSzbSn873EeINw8FMnrt7uCqma5BerDt.png','',8,'2014-06-07 00:11:04','2014-06-07 00:11:04'),
	(15,'6r9NaZ3Mu0555PHsQSKcpEwewioUl8a4.png','',8,'2014-06-07 00:11:04','2014-06-07 00:11:04'),
	(16,'YikqRSlWgwxOXvawaxLRqGS1kE9mwOHM.png','',9,'2014-06-07 00:11:32','2014-06-07 00:11:32'),
	(17,'xJx3aFrKcEg67oS6vvFLcmQxNgI7bu3w.png','',9,'2014-06-07 00:11:32','2014-06-07 00:11:32'),
	(18,'wxkRqixZmAqw2Fv1kvMlCoNELnsRqM3u.png','',10,'2014-06-07 00:11:48','2014-06-07 00:11:48'),
	(19,'CaRCSCq6EFPBaLx9qCtiR2ah3zMTEg8w.png','',10,'2014-06-07 00:11:48','2014-06-07 00:11:48'),
	(20,'dsP9PM6ZfdSuEDWgONbNKIKeacOzfXz6.png','',11,'2014-06-07 00:12:04','2014-06-07 00:12:04'),
	(21,'g207sN4xRcHF2EPCSYktJtlhiNSJwhMa.png','',11,'2014-06-07 00:12:04','2014-06-07 00:12:04'),
	(22,'Q5f3Eysu7mrSLN57yuTEUCArKLP4PQFf.png','',12,'2014-06-07 00:12:20','2014-06-07 00:12:20'),
	(23,'m0OJUAkKlCJbsNEboOt80V5Xet5Oax1m.png','',12,'2014-06-07 00:12:20','2014-06-07 00:12:20'),
	(24,'7xdXj1CDtCkII3zYdshDsnvMJueD8OIv.jpg','',13,'2014-06-07 00:37:34','2014-06-07 00:37:34'),
	(25,'rGOTuyWkY1wcjMJxqeHIPSSkqsNsRuBw.jpg','',14,'2014-06-07 00:45:48','2014-06-07 00:45:48'),
	(26,'9TYLwI6j55DYOO1RvmJbYvUpT26OAHH8.png','',1,'2014-06-11 11:51:49','2014-06-11 11:51:49'),
	(27,'zcqwItJHgcZmtAPysGXtsIptTLhR5VWK.png','',1,'2014-06-11 11:51:49','2014-06-11 11:51:49'),
	(28,'tv5eOqyYUvoCJOHTdp1n9Fe6OJyUhmQi.png','',1,'2014-06-11 11:51:49','2014-06-11 11:51:49'),
	(29,'37RoAG0mbN3QyFRjVWc3nTtSaawGDTqu.png','',1,'2014-06-11 11:51:49','2014-06-11 11:51:49'),
	(30,'sV3FGU9rG4LLDq7IXNToXYJUM6zuOJbu.png','',1,'2014-06-11 11:51:49','2014-06-11 11:51:49'),
	(31,'VOs1eyH83RUPZd0TKyH9BS4IJtiKIkoM.png','',1,'2014-06-11 11:51:49','2014-06-11 11:51:49');

/*!40000 ALTER TABLE `laimages` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table lamanufactors
# ------------------------------------------------------------

DROP TABLE IF EXISTS `lamanufactors`;

CREATE TABLE `lamanufactors` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `latitle` varchar(50) DEFAULT NULL,
  `laurl` varchar(50) DEFAULT NULL,
  `ladeleted` int(11) DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `lainfo` text,
  `laimage` varchar(50) DEFAULT NULL,
  `laorder` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `url` (`laurl`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `lamanufactors` WRITE;
/*!40000 ALTER TABLE `lamanufactors` DISABLE KEYS */;

INSERT INTO `lamanufactors` (`id`, `latitle`, `laurl`, `ladeleted`, `updated_at`, `created_at`, `lainfo`, `laimage`, `laorder`)
VALUES
	(1,'Apple','apple',NULL,'2014-06-06 11:08:00','2014-06-06 09:38:22','','ZpzfOcYcp3HnCUKdXI7dcm3SOjjpTmqQ.jpg',1),
	(2,'Samsung','samsung',NULL,'2014-06-06 11:07:56','2014-06-06 09:38:34','','FyDfuFEeQX5iMS7yk49fY5EhMX3HWdAR.jpg',2),
	(3,'windows phone','windows-phone',NULL,'2014-06-06 11:07:52','2014-06-06 09:38:50','','SOatDqPd6URWgtRKUiWYNXbO2glvHe9A.jpg',3),
	(4,'LG','lg',NULL,'2014-06-06 11:07:47','2014-06-06 09:39:03','','CABP1VfC0XNLPQLxpsFnVC5J2J2JbVBS.jpg',4),
	(5,'htc','htc',NULL,'2014-06-06 11:07:43','2014-06-06 09:39:12','','SwR7vNGBPk3Fm9InjttjJy8efvcPDHS3.png',5),
	(6,'blackberry','blackberry',NULL,'2014-06-06 09:39:25','2014-06-06 09:39:25','','PTEkw7lxn752sjHPC8Si30w32d2VsXml.jpg',6);

/*!40000 ALTER TABLE `lamanufactors` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table laorderitems
# ------------------------------------------------------------

DROP TABLE IF EXISTS `laorderitems`;

CREATE TABLE `laorderitems` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) DEFAULT NULL,
  `latitle` text COLLATE utf8_unicode_ci,
  `amount` int(11) DEFAULT NULL,
  `laprice` int(11) DEFAULT NULL,
  `variantname` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `producturl` text COLLATE utf8_unicode_ci,
  `caturl` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `variantid` int(11) DEFAULT NULL,
  `laimage` text COLLATE utf8_unicode_ci,
  `lakhoiluong` int(11) DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `product_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table laorders
# ------------------------------------------------------------

DROP TABLE IF EXISTS `laorders`;

CREATE TABLE `laorders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `lashipping` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `lapayment` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `lasumkhoiluong` int(11) DEFAULT NULL,
  `lafeeshipping` int(11) DEFAULT NULL,
  `laordername` text COLLATE utf8_unicode_ci,
  `laordertel` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `laorderemail` text COLLATE utf8_unicode_ci,
  `laorderaddr` text COLLATE utf8_unicode_ci,
  `laorderprovince` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `laorderdistrict` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `uid` bigint(20) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `order_status` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  `voucher` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `giamvoucher` int(11) DEFAULT NULL,
  `sumsanpham` int(11) DEFAULT NULL,
  `laordernote` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table laproducts
# ------------------------------------------------------------

DROP TABLE IF EXISTS `laproducts`;

CREATE TABLE `laproducts` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `latitle` varchar(100) DEFAULT '',
  `lakeyword` text,
  `ladescription` text,
  `lashortinfo` text,
  `lainfo` text,
  `lauseguide` text,
  `laimage` varchar(50) DEFAULT NULL,
  `lacategory_id` int(11) DEFAULT '0',
  `lamanufactor_id` int(11) DEFAULT '0',
  `laoldprice` int(11) DEFAULT '0',
  `laprice` int(11) DEFAULT '0',
  `laamount` int(11) DEFAULT '0',
  `ladatenew` varchar(50) DEFAULT '0',
  `ladeleted` int(11) DEFAULT '0',
  `laurl` varchar(100) DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `lakhoiluong` varchar(20) DEFAULT NULL,
  `ladungtich` varchar(100) DEFAULT NULL,
  `laview` int(11) NOT NULL DEFAULT '0',
  `lachucnang` varchar(100) DEFAULT NULL,
  `lavariant_id` int(11) NOT NULL DEFAULT '0',
  `laproduct_id` varchar(50) DEFAULT NULL,
  `youtubeid` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `url` (`laurl`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `laproducts` WRITE;
/*!40000 ALTER TABLE `laproducts` DISABLE KEYS */;

INSERT INTO `laproducts` (`id`, `latitle`, `lakeyword`, `ladescription`, `lashortinfo`, `lainfo`, `lauseguide`, `laimage`, `lacategory_id`, `lamanufactor_id`, `laoldprice`, `laprice`, `laamount`, `ladatenew`, `ladeleted`, `laurl`, `updated_at`, `created_at`, `lakhoiluong`, `ladungtich`, `laview`, `lachucnang`, `lavariant_id`, `laproduct_id`, `youtubeid`)
VALUES
	(1,'Sidebarads','',NULL,'','','','9TYLwI6j55DYOO1RvmJbYvUpT26OAHH8.png',0,0,0,0,0,'-25200',1,'sidebarads','2014-06-11 11:51:49','2014-06-06 17:56:31','','',0,'',0,'',NULL),
	(2,'Giới thiệu','',NULL,'','<p><span style=\"font-family:arial,helvetica,sans-serif; font-size:12px\">Sau hơn 3 năm h&igrave;nh th&agrave;nh v&agrave; ph&aacute;t triển, thương hiệu PhonGee đ&atilde; đi v&agrave;o l&ograve;ng kh&aacute;ch h&agrave;ng bằng niềm tin cậy trọn vẹn v&agrave; sự h&agrave;i l&ograve;ng về chất lượng dịch vụ. V&agrave; giờ đ&acirc;y, PhonGee quyết định n&acirc;ng cấp ch&iacute;nh m&igrave;nh l&ecirc;n một tầm cao mới, dịch vụ đa dạng v&agrave; chuy&ecirc;n nghiệp hơn, c&aacute;c d&ograve;ng sản phẩm cung cấp phong ph&uacute; hơn chứ kh&ocirc;ng chỉ g&oacute;i gọn trong d&ograve;ng sản phẩm Apple cụ thể ở c&aacute;c thương hiệu mạnh kh&aacute;c như Samsung, HTC, Sony, Blackberry,...</span><br />\r\n<br />\r\n<span style=\"font-family:arial,helvetica,sans-serif; font-size:12px\">Ở PhonGee, bạn t&igrave;m thấy được l&ograve;ng tin, t&igrave;m thấy được sự th&acirc;n thiện, sự tận t&acirc;m phục vụ v&agrave; sự chuy&ecirc;n nghiệp trong tư vấn cũng như sự &acirc;n cần trong hỗ trợ.</span><br />\r\n<br />\r\n<span style=\"font-family:arial,helvetica,sans-serif; font-size:12px\">Ở PhonGee, bạn nhận được c&aacute;c gi&aacute; trị cốt l&otilde;i của c&ocirc;ng nghệ từ c&aacute;c sản phẩm ch&iacute;nh h&atilde;ng, nguồn gốc r&otilde; r&agrave;ng minh bạch.</span><br />\r\n<br />\r\n<span style=\"font-family:arial,helvetica,sans-serif; font-size:12px\">Ở PhonGee, bạn biết rằng bạn đ&uacute;ng khi đặt trọn niềm tin, v&agrave; bạn kh&ocirc;ng thất vọng khi trao ban niềm tin đ&oacute;.</span><br />\r\n<br />\r\n<span style=\"font-family:arial,helvetica,sans-serif; font-size:12px\">Giờ đ&acirc;y, PhonGee kh&ocirc;ng chỉ l&agrave; PhonGee, PhonGee đ&atilde; vươn l&ecirc;n 1 tầm mới cao hơn, đa dạng hơn, chuy&ecirc;n nghiệp hơn, CH&Uacute;NG T&Ocirc;I GỌI Đ&Oacute; L&Agrave; SẮC M&Agrave;U PHONGEE, hay dưới t&ecirc;n gọi ngắn gọn: PHONGEE COLOR&nbsp;</span><br />\r\n<br />\r\n<span style=\"font-family:arial,helvetica,sans-serif; font-size:12px\">Bạn đ&atilde; kh&ocirc;ng thất vọng về PhonGee, bạn sẽ c&agrave;ng h&agrave;i l&ograve;ng hơn với PhonGee Color.</span><br />\r\n<br />\r\n<span style=\"font-family:arial,helvetica,sans-serif; font-size:12px\">Ch&uacute;ng t&ocirc;i triển khai hệ thống PhonGee Color ở 02 vị tr&iacute;:</span><br />\r\n<span style=\"font-family:arial,helvetica,sans-serif; font-size:12px\">- 12 Trần Quốc Ho&agrave;n, phường 4, quận T&acirc;n B&igrave;nh, TP HCM</span><br />\r\n<span style=\"font-family:arial,helvetica,sans-serif; font-size:12px\">- 12 T&ocirc;n Thất T&ugrave;ng, Phường Bến Th&agrave;nh, quận 1, TPHCM</span><br />\r\n<br />\r\n<span style=\"font-family:arial,helvetica,sans-serif; font-size:12px\">C&aacute;c địa điểm kh&aacute;c đang nhượng quyền thương hiệu PhonGee (chứ kh&ocirc;ng d&ugrave;ng PhonGee Color) kh&ocirc;ng trực thuộc hệ thống PhonGee ch&uacute;ng t&ocirc;i.</span></p>\r\n','','W32Z1e4FzNREcZc2y3isgNZBslcvXJsv.png',7,0,0,0,0,'-25200',0,'gioi-thieu','2014-06-09 06:25:53','2014-06-06 23:35:57','','',4,'',0,'',NULL),
	(3,'iPhone 5s 16GB','iphone, iOS',NULL,'','','','D4pKkC5qz3EaneohRj62RKtp4mB2IXUd.png',3,1,0,14890000,0,'1404061200',0,'iphone-5s-16gb','2014-07-20 01:51:46','2014-06-06 23:50:07','','',16,'',0,'',NULL),
	(4,'iPhone 5s 16GB','iphone, iOS',NULL,'Sliver','','','L0aZq7OHKSg56SFrtQpynFpH9U2naCWr.png',3,1,0,14890000,0,'1404061200',0,'iphone-5s-16gb1','2014-06-06 23:50:44','2014-06-06 23:50:44','','',0,'',3,'',NULL),
	(5,'iPhone 5s 16GB','iphone, iOS',NULL,'Gold','','','LyWSOsF8eYYwPqkA3NJDOjZtP2QNNOmY.png',3,1,0,14890000,0,'1404061200',0,'iphone-5s-16gb2','2014-06-06 23:51:11','2014-06-06 23:51:11','','',0,'',3,'',NULL),
	(6,'iPhone 5s 16GB','iphone, iOS',NULL,'Space Gray','','','qtTsHL2Z5FeRC0fLgD35paA5p0I3O53Y.png',3,1,0,14890000,0,'1404061200',0,'iphone-5s-16gb3','2014-06-06 23:52:20','2014-06-06 23:52:07','','',0,'',3,'',NULL),
	(7,'iPhone 5c 16GB','',NULL,'','<h2><br />\r\n&nbsp;</h2>\r\n','','93B8ko9arNBj5GTlAWDj6EZvua8fl7Y3.png',3,1,0,10790000,0,'1404061200',0,'iphone-5c-16gb','2014-07-20 01:42:47','2014-06-07 00:10:39','132','59.2 mm x 124.4 mm x 9.97 mm',38,'',0,'',NULL),
	(8,'iPhone 5c 16GB','',NULL,'White','','','6r9NaZ3Mu0555PHsQSKcpEwewioUl8a4.png',3,1,0,10790000,0,'1404061200',0,'iphone-5c-16gb1','2014-06-07 00:11:04','2014-06-07 00:11:04','','',0,'',7,'',NULL),
	(9,'iPhone 5c 16GB','',NULL,'Blue','','','xJx3aFrKcEg67oS6vvFLcmQxNgI7bu3w.png',3,1,0,10790000,0,'1404061200',0,'iphone-5c-16gb2','2014-06-07 00:11:32','2014-06-07 00:11:32','','',0,'',7,'',NULL),
	(10,'iPhone 5c 16GB','',NULL,'Green','','','CaRCSCq6EFPBaLx9qCtiR2ah3zMTEg8w.png',3,1,0,10790000,0,'1404061200',0,'iphone-5c-16gb3','2014-06-07 00:11:48','2014-06-07 00:11:48','','',0,'',7,'',NULL),
	(11,'iPhone 5c 16GB','',NULL,'Red','','','dsP9PM6ZfdSuEDWgONbNKIKeacOzfXz6.png',3,1,0,10790000,0,'1404061200',0,'iphone-5c-16gb4','2014-06-07 00:12:04','2014-06-07 00:12:04','','',0,'',7,'',NULL),
	(12,'iPhone 5c 16GB','',NULL,'Yellow','','','m0OJUAkKlCJbsNEboOt80V5Xet5Oax1m.png',3,1,0,10790000,0,'1404061200',0,'iphone-5c-16gb5','2014-06-07 00:12:20','2014-06-07 00:12:20','','',0,'',7,'',NULL),
	(13,'Người đẹp và công nghệ ở Computex','',NULL,'Ở đâu có công nghệ thì ở đó có người đẹp, dĩ nhiên là kể cả Computex 2014, được diễn ra từ ngày 3-7/6 năm nay ở Đài Bắc, Đài Loan','<p><span style=\"background-color:rgb(252, 252, 255); color:rgb(20, 20, 20); font-family:helvetica,arial,sans-serif; font-size:15px\">Ở đ&acirc;u c&oacute; c&ocirc;ng nghệ th&igrave; ở đ&oacute; c&oacute; người đẹp, dĩ nhi&ecirc;n l&agrave; kể cả&nbsp;</span><a class=\"Tinhte_XenTag_TagLink\" href=\"http://www.tinhte.vn/tags/computex+2014/\" style=\"color: rgb(13, 89, 143); text-decoration: none; border-top-left-radius: 5px; border-top-right-radius: 5px; border-bottom-right-radius: 5px; border-bottom-left-radius: 5px; padding: 0px 3px; margin: 0px -3px; font-family: Helvetica, Arial, sans-serif; font-size: 15px; line-height: 20.533334732055664px; text-align: justify; background-color: rgb(252, 252, 255);\" target=\"_blank\">Computex 2014</a><span style=\"background-color:rgb(252, 252, 255); color:rgb(20, 20, 20); font-family:helvetica,arial,sans-serif; font-size:15px\">, được diễn ra từ ng&agrave;y 3-7/6 năm nay ở Đ&agrave;i Bắc, Đ&agrave;i Loan. Với một sự kiện quốc tế th&igrave; sự xuất hiện của c&aacute;c&nbsp;</span><a class=\"Tinhte_XenTag_TagLink\" href=\"http://www.tinhte.vn/tags/pg+xinh+%C4%91%E1%BA%B9p/\" style=\"color: rgb(13, 89, 143); text-decoration: none; border-top-left-radius: 5px; border-top-right-radius: 5px; border-bottom-right-radius: 5px; border-bottom-left-radius: 5px; padding: 0px 3px; margin: 0px -3px; font-family: Helvetica, Arial, sans-serif; font-size: 15px; line-height: 20.533334732055664px; text-align: justify; background-color: rgb(252, 252, 255);\" target=\"_blank\">PG xinh đẹp</a><span style=\"background-color:rgb(252, 252, 255); color:rgb(20, 20, 20); font-family:helvetica,arial,sans-serif; font-size:15px\">&nbsp;cũng nhiều hơn, đều đặn v&agrave; xinh tươi hơn, v&agrave; với sự niềm nở, hiếu kh&aacute;ch, nhiệt t&igrave;nh tư vấn th&igrave; PG ch&iacute;nh l&agrave; cầu nối để sự kiện diễn ra th&agrave;nh c&ocirc;ng. Mời c&aacute;c bạn xem qua v&agrave;i h&igrave;nh ảnh về c&aacute;c c&ocirc; g&aacute;i n&agrave;y ở Computex 2014 năm nay.</span><br />\r\n<br />\r\n<img alt=\"fh (1).\" class=\"LbImage bbCodeImage\" src=\"http://photo.tinhte.vn/store/2014/06/2504997_fh_1.jpg\" style=\"background-color:rgb(252, 252, 255); border:0px; color:rgb(20, 20, 20); font-family:helvetica,arial,sans-serif; font-size:15px; line-height:20.533334732055664px; max-width:100%; text-align:justify\" /><img alt=\"fh (3).\" class=\"LbImage bbCodeImage\" src=\"http://photo.tinhte.vn/store/2014/06/2504998_fh_3.jpg\" style=\"background-color:rgb(252, 252, 255); border:0px; color:rgb(20, 20, 20); font-family:helvetica,arial,sans-serif; font-size:15px; line-height:20.533334732055664px; max-width:100%; text-align:justify\" /><img alt=\"fh (6).\" class=\"LbImage bbCodeImage\" src=\"http://photo.tinhte.vn/store/2014/06/2504999_fh_6.jpg\" style=\"background-color:rgb(252, 252, 255); border:0px; color:rgb(20, 20, 20); font-family:helvetica,arial,sans-serif; font-size:15px; line-height:20.533334732055664px; max-width:100%; text-align:justify\" /><br />\r\n<img alt=\"nguoi-dep-o-computex-2014 (3).\" class=\"LbImage bbCodeImage\" src=\"http://photo.tinhte.vn/store/2014/06/2505005_nguoi-dep-o-computex-2014_3.jpg\" style=\"background-color:rgb(252, 252, 255); border:0px; color:rgb(20, 20, 20); font-family:helvetica,arial,sans-serif; font-size:15px; line-height:20.533334732055664px; max-width:100%; text-align:justify\" /><br />\r\n<img alt=\"computex2014 (1).\" class=\"LbImage bbCodeImage\" src=\"http://photo.tinhte.vn/store/2014/06/2505156_computex2014_1.jpg\" style=\"background-color:rgb(252, 252, 255); border:0px; color:rgb(20, 20, 20); font-family:helvetica,arial,sans-serif; font-size:15px; line-height:20.533334732055664px; max-width:100%; text-align:justify\" /><img alt=\"computex2014 (2).\" class=\"LbImage bbCodeImage\" src=\"http://photo.tinhte.vn/store/2014/06/2505157_computex2014_2.jpg\" style=\"background-color:rgb(252, 252, 255); border:0px; color:rgb(20, 20, 20); font-family:helvetica,arial,sans-serif; font-size:15px; line-height:20.533334732055664px; max-width:100%; text-align:justify\" /><img alt=\"computex2014 (4).\" class=\"LbImage bbCodeImage\" src=\"http://photo.tinhte.vn/store/2014/06/2505159_computex2014_4.jpg\" style=\"background-color:rgb(252, 252, 255); border:0px; color:rgb(20, 20, 20); font-family:helvetica,arial,sans-serif; font-size:15px; line-height:20.533334732055664px; max-width:100%; text-align:justify\" /><img alt=\"computex2014 (5).\" class=\"LbImage bbCodeImage\" src=\"http://photo.tinhte.vn/store/2014/06/2505160_computex2014_5.jpg\" style=\"background-color:rgb(252, 252, 255); border:0px; color:rgb(20, 20, 20); font-family:helvetica,arial,sans-serif; font-size:15px; line-height:20.533334732055664px; max-width:100%; text-align:justify\" /><img alt=\"computex2014 (6).\" class=\"LbImage bbCodeImage\" src=\"http://photo.tinhte.vn/store/2014/06/2505161_computex2014_6.jpg\" style=\"background-color:rgb(252, 252, 255); border:0px; color:rgb(20, 20, 20); font-family:helvetica,arial,sans-serif; font-size:15px; line-height:20.533334732055664px; max-width:100%; text-align:justify\" /><img alt=\"computex2014 (7).\" class=\"LbImage bbCodeImage\" src=\"http://photo.tinhte.vn/store/2014/06/2505162_computex2014_7.jpg\" style=\"background-color:rgb(252, 252, 255); border:0px; color:rgb(20, 20, 20); font-family:helvetica,arial,sans-serif; font-size:15px; line-height:20.533334732055664px; max-width:100%; text-align:justify\" /><img alt=\"computex2014 (8).\" class=\"LbImage bbCodeImage\" src=\"http://photo.tinhte.vn/store/2014/06/2505163_computex2014_8.jpg\" style=\"background-color:rgb(252, 252, 255); border:0px; color:rgb(20, 20, 20); font-family:helvetica,arial,sans-serif; font-size:15px; line-height:20.533334732055664px; max-width:100%; text-align:justify\" /><img alt=\"computex2014 (9).\" class=\"LbImage bbCodeImage\" src=\"http://photo.tinhte.vn/store/2014/06/2505164_computex2014_9.jpg\" style=\"background-color:rgb(252, 252, 255); border:0px; color:rgb(20, 20, 20); font-family:helvetica,arial,sans-serif; font-size:15px; line-height:20.533334732055664px; max-width:100%; text-align:justify\" /><img alt=\"computex2014 (10).\" class=\"LbImage bbCodeImage\" src=\"http://photo.tinhte.vn/store/2014/06/2505165_computex2014_10.jpg\" style=\"background-color:rgb(252, 252, 255); border:0px; color:rgb(20, 20, 20); font-family:helvetica,arial,sans-serif; font-size:15px; line-height:20.533334732055664px; max-width:100%; text-align:justify\" /><img alt=\"computex2014 (11).\" class=\"LbImage bbCodeImage\" src=\"http://photo.tinhte.vn/store/2014/06/2505166_computex2014_11.jpg\" style=\"background-color:rgb(252, 252, 255); border:0px; color:rgb(20, 20, 20); font-family:helvetica,arial,sans-serif; font-size:15px; line-height:20.533334732055664px; max-width:100%; text-align:justify\" /></p>\r\n\r\n<div style=\"margin: 0px; padding: 0px; color: rgb(20, 20, 20); font-family: Helvetica, Arial, sans-serif; font-size: 15px; line-height: 20.533334732055664px; text-align: center; background-color: rgb(252, 252, 255);\"><img alt=\"fh (9).\" class=\"LbImage bbCodeImage\" src=\"http://photo.tinhte.vn/store/2014/06/2505000_fh_9.jpg\" style=\"border:0px; max-width:100%\" /><img alt=\"fh (10).\" class=\"LbImage bbCodeImage\" src=\"http://photo.tinhte.vn/store/2014/06/2505001_fh_10.jpg\" style=\"border:0px; max-width:100%\" /><img alt=\"nguoi-dep-o-computex-2014 (1).\" class=\"LbImage bbCodeImage\" src=\"http://photo.tinhte.vn/store/2014/06/2505003_nguoi-dep-o-computex-2014_1.jpg\" style=\"border:0px; max-width:100%\" /><img alt=\"nguoi-dep-o-computex-2014 (2).\" class=\"LbImage bbCodeImage\" src=\"http://photo.tinhte.vn/store/2014/06/2505004_nguoi-dep-o-computex-2014_2.jpg\" style=\"border:0px; max-width:100%\" /><img alt=\"nguoi-dep-o-computex-2014 (4).\" class=\"LbImage bbCodeImage\" src=\"http://photo.tinhte.vn/store/2014/06/2505006_nguoi-dep-o-computex-2014_4.jpg\" style=\"border:0px; max-width:100%\" />&nbsp;<br />\r\n<img alt=\"computex (4).\" class=\"LbImage bbCodeImage\" src=\"http://photo.tinhte.vn/store/2014/06/2506628_computex_4.jpg\" style=\"border:0px; max-width:100%\" /><br />\r\n<img alt=\"nguoi-dep-o-computex-2014 (7).\" class=\"LbImage bbCodeImage\" src=\"http://photo.tinhte.vn/store/2014/06/2505009_nguoi-dep-o-computex-2014_7.jpg\" style=\"border:0px; max-width:100%\" /><img alt=\"nguoi-dep-o-computex-2014 (9).\" class=\"LbImage bbCodeImage\" src=\"http://photo.tinhte.vn/store/2014/06/2505010_nguoi-dep-o-computex-2014_9.jpg\" style=\"border:0px; max-width:100%\" /><img alt=\"nguoi-dep-o-computex-2014 (10).\" class=\"LbImage bbCodeImage\" src=\"http://photo.tinhte.vn/store/2014/06/2505011_nguoi-dep-o-computex-2014_10.jpg\" style=\"border:0px; max-width:100%\" /><img alt=\"nguoi-dep-o-computex-2014 (11).\" class=\"LbImage bbCodeImage\" src=\"http://photo.tinhte.vn/store/2014/06/2505012_nguoi-dep-o-computex-2014_11.jpg\" style=\"border:0px; max-width:100%\" /><img alt=\"nguoi-dep-o-computex-2014 (12).\" class=\"LbImage bbCodeImage\" src=\"http://photo.tinhte.vn/store/2014/06/2505013_nguoi-dep-o-computex-2014_12.jpg\" style=\"border:0px; max-width:100%\" /><img alt=\"nguoi-dep-o-computex-2014 (13).\" class=\"LbImage bbCodeImage\" src=\"http://photo.tinhte.vn/store/2014/06/2505014_nguoi-dep-o-computex-2014_13.jpg\" style=\"border:0px; max-width:100%\" /><img alt=\"nguoi-dep-o-computex-2014 (14).\" class=\"LbImage bbCodeImage\" src=\"http://photo.tinhte.vn/store/2014/06/2505015_nguoi-dep-o-computex-2014_14.jpg\" style=\"border:0px; max-width:100%\" /><img alt=\"nguoi-dep-o-computex-2014 (15).\" class=\"LbImage bbCodeImage\" src=\"http://photo.tinhte.vn/store/2014/06/2505016_nguoi-dep-o-computex-2014_15.jpg\" style=\"border:0px; max-width:100%\" /><img alt=\"nguoi-dep-o-computex-2014 (16).\" class=\"LbImage bbCodeImage\" src=\"http://photo.tinhte.vn/store/2014/06/2505017_nguoi-dep-o-computex-2014_16.jpg\" style=\"border:0px; max-width:100%\" /><img alt=\"nguoi-dep-o-computex-2014 (17).\" class=\"LbImage bbCodeImage\" src=\"http://photo.tinhte.vn/store/2014/06/2505018_nguoi-dep-o-computex-2014_17.jpg\" style=\"border:0px; max-width:100%\" /><img alt=\"nguoi-dep-o-computex-2014 (18).\" class=\"LbImage bbCodeImage\" src=\"http://photo.tinhte.vn/store/2014/06/2505019_nguoi-dep-o-computex-2014_18.jpg\" style=\"border:0px; max-width:100%\" />&nbsp;<br />\r\n<img alt=\"computex (1).\" class=\"LbImage bbCodeImage\" src=\"http://photo.tinhte.vn/store/2014/06/2506625_computex_1.jpg\" style=\"border:0px; max-width:100%\" /><img alt=\"computex (2).\" class=\"LbImage bbCodeImage\" src=\"http://photo.tinhte.vn/store/2014/06/2506626_computex_2.jpg\" style=\"border:0px; max-width:100%\" /><img alt=\"computex (3).\" class=\"LbImage bbCodeImage\" src=\"http://photo.tinhte.vn/store/2014/06/2506627_computex_3.jpg\" style=\"border:0px; max-width:100%\" />&nbsp;<br />\r\n<img alt=\"computex (6).\" class=\"LbImage bbCodeImage\" src=\"http://photo.tinhte.vn/store/2014/06/2506630_computex_6.jpg\" style=\"border:0px; max-width:100%\" /><img alt=\"computex (7).\" class=\"LbImage bbCodeImage\" src=\"http://photo.tinhte.vn/store/2014/06/2506631_computex_7.jpg\" style=\"border:0px; max-width:100%\" /><img alt=\"computex (8).\" class=\"LbImage bbCodeImage\" src=\"http://photo.tinhte.vn/store/2014/06/2506632_computex_8.jpg\" style=\"border:0px; max-width:100%\" /></div>\r\n','','7xdXj1CDtCkII3zYdshDsnvMJueD8OIv.jpg',10,0,0,0,0,'0',0,'nguoi-dep-va-cong-nghe-o-computex','2014-06-11 11:43:45','2014-06-07 00:37:34','','',10,'',0,'',NULL),
	(14,'Safari có thêm chức năng đọc thông tin thẻ tín dụng bằng camera','',NULL,'Trình duyệt Safari trên iOS 8 có thêm một chức năng mới đó là dùng camera để đọc thông tin trên tín dụng hoặc các loại thẻ ngân hàng','<p><span style=\"background-color:rgb(252, 252, 255); color:rgb(20, 20, 20); font-family:helvetica,arial,sans-serif; font-size:15px\">Tr&igrave;nh duyệt&nbsp;</span><a class=\"Tinhte_XenTag_TagLink\" href=\"http://www.tinhte.vn/tags/safari/\" style=\"color: rgb(13, 89, 143); text-decoration: none; border-top-left-radius: 5px; border-top-right-radius: 5px; border-bottom-right-radius: 5px; border-bottom-left-radius: 5px; padding: 0px 3px; margin: 0px -3px; font-family: Helvetica, Arial, sans-serif; font-size: 15px; line-height: 20.533334732055664px; text-align: justify; background-color: rgb(252, 252, 255);\" target=\"_blank\">Safari</a><span style=\"background-color:rgb(252, 252, 255); color:rgb(20, 20, 20); font-family:helvetica,arial,sans-serif; font-size:15px\">&nbsp;tr&ecirc;n&nbsp;</span><a class=\"Tinhte_XenTag_TagLink\" href=\"http://www.tinhte.vn/tags/ios+8/\" style=\"color: rgb(13, 89, 143); text-decoration: none; border-top-left-radius: 5px; border-top-right-radius: 5px; border-bottom-right-radius: 5px; border-bottom-left-radius: 5px; padding: 0px 3px; margin: 0px -3px; font-family: Helvetica, Arial, sans-serif; font-size: 15px; line-height: 20.533334732055664px; text-align: justify; background-color: rgb(252, 252, 255);\" target=\"_blank\">iOS 8</a><span style=\"background-color:rgb(252, 252, 255); color:rgb(20, 20, 20); font-family:helvetica,arial,sans-serif; font-size:15px\">&nbsp;c&oacute; th&ecirc;m một chức năng mới đ&oacute; l&agrave; d&ugrave;ng camera để đọc th&ocirc;ng tin tr&ecirc;n t&iacute;n dụng hoặc c&aacute;c loại thẻ ng&acirc;n h&agrave;ng. Khi đang mua h&agrave;ng online v&agrave; đến phần nhập th&ocirc;ng tin thẻ, thay v&igrave; ngồi nhập từng con số th&igrave; bạn chỉ việc chĩa camera v&agrave;o chiếc thẻ của m&igrave;nh, m&aacute;y sẽ tự động nhận diện c&aacute;c con số v&agrave; điền v&agrave;o chỗ trống gi&uacute;p bạn. Chức năng n&agrave;y trong tương lai sẽ gi&uacute;p ch&uacute;ng ta tiết kiệm được thời gian nhập liệu cũng như hạn chế bớt t&igrave;nh trạng bị hacker đ&aacute;nh cắp th&ocirc;ng tin th&ocirc;ng qua c&aacute;c phần mềm keylogger.</span><br />\r\n<br />\r\n<span style=\"background-color:rgb(252, 252, 255); color:rgb(20, 20, 20); font-family:helvetica,arial,sans-serif; font-size:15px\">Chức năng n&agrave;y ho&agrave;n to&agrave;n tự động n&ecirc;n người quản trị mạng kh&ocirc;ng cần phải c&agrave;i đặt g&igrave; tr&ecirc;n website của họ. Khi đến &ocirc; nhập th&ocirc;ng tin thẻ (số thẻ), tr&igrave;nh duyệt sẽ tự động nhận biết v&agrave; đưa ra một t&ugrave;y chọn t&ecirc;n l&agrave; &quot;</span><em>Scan Credit Card</em><span style=\"background-color:rgb(252, 252, 255); color:rgb(20, 20, 20); font-family:helvetica,arial,sans-serif; font-size:15px\">&quot; nằm ph&iacute;a tr&ecirc;n b&agrave;n ph&iacute;m, nhấn v&agrave;o đ&oacute; lập tức giao diện chụp h&igrave;nh sẽ xuất hiện c&ugrave;ng với một c&aacute;i khung. Bạn chĩa c&aacute;i khung n&agrave;y v&agrave;o đ&uacute;ng thẻ ng&acirc;n h&agrave;ng của m&igrave;nh th&igrave; m&aacute;y sẽ tự động nhận dạng h&igrave;nh ảnh v&agrave; tr&iacute;ch xuất th&ocirc;ng tin ra từ đ&oacute;.</span><br />\r\n<br />\r\n<span style=\"background-color:rgb(252, 252, 255); color:rgb(20, 20, 20); font-family:helvetica,arial,sans-serif; font-size:15px\">M&igrave;nh đ&atilde; thử v&agrave; thấy chức năng n&agrave;y hoạt động được nhưng thời gian nhận dạng qu&aacute; l&acirc;u, c&oacute; lẽ do c&ograve;n l&agrave; bản thử nghiệm (beta 1) n&ecirc;n n&oacute; chưa ph&aacute;t huy hết hiệu quả.</span></p>\r\n','','rGOTuyWkY1wcjMJxqeHIPSSkqsNsRuBw.jpg',10,0,0,0,0,'0',0,'safari-co-them-chuc-nang-doc-thong-tin-the-tin-dung-bang-camera','2014-06-11 11:43:36','2014-06-07 00:45:48','','',12,'',0,'',NULL),
	(16,'iPhone 5s 16GB','iphone, iOS',NULL,'','','','D4pKkC5qz3EaneohRj62RKtp4mB2IXUd.png',3,1,0,14890000,0,'1404061200',0,'iphone-5s-16gb01','2014-07-15 16:08:41','2014-06-06 23:50:07','','',15,'',0,'',NULL),
	(17,'iPhone 5s 16GB','iphone, iOS',NULL,'','','','D4pKkC5qz3EaneohRj62RKtp4mB2IXUd.png',3,1,0,14890000,0,'1404061200',0,'iphone-5s-16gb02','2014-07-15 16:08:41','2014-06-06 23:50:07','','',15,'',0,'',NULL),
	(18,'iPhone 5s 16GB','iphone, iOS',NULL,'','','','D4pKkC5qz3EaneohRj62RKtp4mB2IXUd.png',3,1,0,14890000,0,'1404061200',0,'iphone-5s-16gb03','2014-07-15 16:08:41','2014-06-06 23:50:07','','',15,'',0,'',NULL),
	(19,'iPhone 5s 16GB','iphone, iOS',NULL,'','','','D4pKkC5qz3EaneohRj62RKtp4mB2IXUd.png',3,1,0,14890000,0,'1404061200',0,'iphone-5s-16gb04','2014-07-15 16:08:41','2014-06-06 23:50:07','','',15,'',0,'',NULL),
	(20,'iPhone 5s 16GB','iphone, iOS',NULL,'','','','D4pKkC5qz3EaneohRj62RKtp4mB2IXUd.png',3,1,0,14890000,0,'1404061200',0,'iphone-5s-16gb09','2014-07-15 16:08:41','2014-06-06 23:50:07','','',15,'',0,'',NULL),
	(21,'iPhone 5s 16GB','iphone, iOS',NULL,'','','','D4pKkC5qz3EaneohRj62RKtp4mB2IXUd.png',3,1,0,14890000,0,'1404061200',0,'iphone-5s-16gb07','2014-07-20 01:41:17','2014-06-06 23:50:07','','',16,'',0,'',NULL),
	(22,'iPhone 5s 16GB','iphone, iOS',NULL,'','','','D4pKkC5qz3EaneohRj62RKtp4mB2IXUd.png',3,1,0,14890000,0,'1404061200',0,'iphone-5s-16gb08','2014-07-15 16:08:41','2014-06-06 23:50:07','','',15,'',0,'',NULL),
	(23,'iPhone 5s 16GB','iphone, iOS',NULL,'','','','D4pKkC5qz3EaneohRj62RKtp4mB2IXUd.png',3,1,0,14890000,0,'1404061200',0,'iphone-5s-16gb12','2014-07-15 16:08:41','2014-06-06 23:50:07','','',15,'',0,'',NULL),
	(24,'iPhone 5s 16GB','iphone, iOS',NULL,'','','','D4pKkC5qz3EaneohRj62RKtp4mB2IXUd.png',3,1,0,14890000,0,'1404061200',0,'iphone-5s-16gb11','2014-07-15 16:08:41','2014-06-06 23:50:07','','',15,'',0,'',NULL),
	(25,'iPhone 5s 16GB','iphone, iOS',NULL,'','','','D4pKkC5qz3EaneohRj62RKtp4mB2IXUd.png',3,1,0,14890000,0,'1404061200',0,'iphone-5s-16gb10','2014-07-15 16:08:41','2014-06-06 23:50:07','','',15,'',0,'',NULL);

/*!40000 ALTER TABLE `laproducts` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table latags
# ------------------------------------------------------------

DROP TABLE IF EXISTS `latags`;

CREATE TABLE `latags` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `latitle` varchar(50) CHARACTER SET latin1 DEFAULT NULL,
  `laproduct_id` int(11) DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table lauser
# ------------------------------------------------------------

DROP TABLE IF EXISTS `lauser`;

CREATE TABLE `lauser` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(100) DEFAULT NULL,
  `password` varchar(100) DEFAULT NULL,
  `larole` varchar(20) DEFAULT NULL,
  `lastatus` int(11) DEFAULT NULL,
  `lafullname` varchar(100) DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `laemail` varchar(50) DEFAULT NULL,
  `laphoto` text,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `lauser` WRITE;
/*!40000 ALTER TABLE `lauser` DISABLE KEYS */;

INSERT INTO `lauser` (`id`, `username`, `password`, `larole`, `lastatus`, `lafullname`, `updated_at`, `created_at`, `laemail`, `laphoto`)
VALUES
	(1,'admin','$2y$10$cn2evPkX0GMyAWcUZ37ab.1ilTXucy9oitCo7qOnUzBso0KAgQmsi','admin',1,'Administrator','2014-04-07 23:53:53',NULL,NULL,NULL);

/*!40000 ALTER TABLE `lauser` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table lausers
# ------------------------------------------------------------

DROP TABLE IF EXISTS `lausers`;

CREATE TABLE `lausers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `laemail` text COLLATE utf8_unicode_ci,
  `laphoto` text COLLATE utf8_unicode_ci,
  `laname` text COLLATE utf8_unicode_ci,
  `lapassword` text COLLATE utf8_unicode_ci,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table v_categories
# ------------------------------------------------------------

DROP VIEW IF EXISTS `v_categories`;

CREATE TABLE `v_categories` (
   `id` INT(11) UNSIGNED NOT NULL DEFAULT '0',
   `latitle` VARCHAR(50) NULL DEFAULT NULL,
   `laparent_id` INT(11) NULL DEFAULT NULL,
   `laurl` VARCHAR(50) NULL DEFAULT NULL,
   `lainfo` TEXT NULL DEFAULT NULL,
   `ladeleted` INT(11) NOT NULL DEFAULT '0',
   `laorder` INT(11) NULL DEFAULT NULL,
   `laimage` VARCHAR(50) NULL DEFAULT NULL,
   `updated_at` TIMESTAMP NULL DEFAULT NULL,
   `created_at` TIMESTAMP NULL DEFAULT NULL,
   `laicon` VARCHAR(100) NOT NULL DEFAULT 'glyphicon glyphicon-link',
   `isnews` INT(1) NOT NULL DEFAULT '0',
   `numproduct` BIGINT(21) NOT NULL DEFAULT '0'
) ENGINE=MyISAM;



# Dump of table v_products
# ------------------------------------------------------------

DROP VIEW IF EXISTS `v_products`;

CREATE TABLE `v_products` (
   `id` INT(11) UNSIGNED NOT NULL DEFAULT '0',
   `latitle` VARCHAR(100) NULL DEFAULT '',
   `lakeyword` TEXT NULL DEFAULT NULL,
   `ladescription` TEXT NULL DEFAULT NULL,
   `lashortinfo` TEXT NULL DEFAULT NULL,
   `lainfo` TEXT NULL DEFAULT NULL,
   `lauseguide` TEXT NULL DEFAULT NULL,
   `laimage` VARCHAR(50) NULL DEFAULT NULL,
   `lacategory_id` INT(11) NULL DEFAULT '0',
   `lamanufactor_id` INT(11) NULL DEFAULT '0',
   `laoldprice` INT(11) NULL DEFAULT '0',
   `laprice` INT(11) NULL DEFAULT '0',
   `laamount` INT(11) NULL DEFAULT '0',
   `ladatenew` VARCHAR(50) NULL DEFAULT '0',
   `ladeleted` INT(11) NULL DEFAULT '0',
   `laurl` VARCHAR(100) NULL DEFAULT NULL,
   `updated_at` TIMESTAMP NULL DEFAULT NULL,
   `created_at` TIMESTAMP NULL DEFAULT NULL,
   `lakhoiluong` VARCHAR(20) NULL DEFAULT NULL,
   `ladungtich` VARCHAR(100) NULL DEFAULT NULL,
   `laview` INT(11) NOT NULL DEFAULT '0',
   `lachucnang` VARCHAR(100) NULL DEFAULT NULL,
   `lavariant_id` INT(11) NOT NULL DEFAULT '0',
   `laproduct_id` VARCHAR(50) NULL DEFAULT NULL,
   `sumvariant` BIGINT(21) NULL DEFAULT NULL,
   `cat1id` INT(11) UNSIGNED NULL DEFAULT '0',
   `cat1name` VARCHAR(50) NULL DEFAULT NULL,
   `cat1url` VARCHAR(50) NULL DEFAULT NULL,
   `cat1deleted` INT(11) NULL DEFAULT '0',
   `isnews` INT(1) NULL DEFAULT '0',
   `cat2id` DECIMAL(11) NULL DEFAULT NULL,
   `cat2name` VARCHAR(50) NULL DEFAULT NULL,
   `cat2url` VARCHAR(50) NULL DEFAULT NULL,
   `cat3id` DECIMAL(11) NULL DEFAULT NULL,
   `cat3name` VARCHAR(50) NULL DEFAULT NULL,
   `cat3url` VARCHAR(50) NULL DEFAULT NULL,
   `factorid` INT(11) UNSIGNED NULL DEFAULT '0',
   `factorname` VARCHAR(50) NULL DEFAULT NULL,
   `factorurl` VARCHAR(50) NULL DEFAULT NULL,
   `pricechange` BIGINT(12) NULL DEFAULT NULL,
   `numorder` DECIMAL(32) NULL DEFAULT NULL
) ENGINE=MyISAM;





# Replace placeholder table for v_categories with correct view syntax
# ------------------------------------------------------------

DROP TABLE `v_categories`;

CREATE ALGORITHM=UNDEFINED DEFINER=`daklaksa`@`localhost` SQL SECURITY DEFINER VIEW `v_categories`
AS SELECT
   `c`.`id` AS `id`,
   `c`.`latitle` AS `latitle`,
   `c`.`laparent_id` AS `laparent_id`,
   `c`.`laurl` AS `laurl`,
   `c`.`lainfo` AS `lainfo`,
   `c`.`ladeleted` AS `ladeleted`,
   `c`.`laorder` AS `laorder`,
   `c`.`laimage` AS `laimage`,
   `c`.`updated_at` AS `updated_at`,
   `c`.`created_at` AS `created_at`,
   `c`.`laicon` AS `laicon`,
   `c`.`isnews` AS `isnews`,count(`p`.`id`) AS `numproduct`
FROM (`lacategories` `c` left join `v_products` `p` on(((`p`.`cat1id` = `c`.`id`) or (`p`.`cat2id` = `c`.`id`) or (`p`.`cat3id` = `c`.`id`)))) where ((`c`.`ladeleted` <> 1) or isnull(`c`.`ladeleted`)) group by `c`.`id`;


# Replace placeholder table for v_products with correct view syntax
# ------------------------------------------------------------

DROP TABLE `v_products`;

CREATE ALGORITHM=UNDEFINED DEFINER=`daklaksa_phongee`@`%` SQL SECURITY DEFINER VIEW `v_products`
AS SELECT
   `p`.`id` AS `id`,
   `p`.`latitle` AS `latitle`,
   `p`.`lakeyword` AS `lakeyword`,
   `p`.`ladescription` AS `ladescription`,
   `p`.`lashortinfo` AS `lashortinfo`,
   `p`.`lainfo` AS `lainfo`,
   `p`.`lauseguide` AS `lauseguide`,
   `p`.`laimage` AS `laimage`,
   `p`.`lacategory_id` AS `lacategory_id`,
   `p`.`lamanufactor_id` AS `lamanufactor_id`,
   `p`.`laoldprice` AS `laoldprice`,
   `p`.`laprice` AS `laprice`,
   `p`.`laamount` AS `laamount`,
   `p`.`ladatenew` AS `ladatenew`,
   `p`.`ladeleted` AS `ladeleted`,
   `p`.`laurl` AS `laurl`,
   `p`.`updated_at` AS `updated_at`,
   `p`.`created_at` AS `created_at`,
   `p`.`lakhoiluong` AS `lakhoiluong`,
   `p`.`ladungtich` AS `ladungtich`,
   `p`.`laview` AS `laview`,
   `p`.`lachucnang` AS `lachucnang`,
   `p`.`lavariant_id` AS `lavariant_id`,
   `p`.`laproduct_id` AS `laproduct_id`,(select count(`p2`.`id`)
FROM `laproducts` `p2` where (`p2`.`lavariant_id` = `p`.`id`)) AS `sumvariant`,`c1`.`id` AS `cat1id`,`c1`.`latitle` AS `cat1name`,`c1`.`laurl` AS `cat1url`,`c1`.`ladeleted` AS `cat1deleted`,`c1`.`isnews` AS `isnews`,coalesce(`c2`.`id`,0) AS `cat2id`,coalesce(`c2`.`latitle`,'') AS `cat2name`,coalesce(`c2`.`laurl`,'') AS `cat2url`,coalesce(`c3`.`id`,0) AS `cat3id`,coalesce(`c3`.`latitle`,'') AS `cat3name`,coalesce(`c3`.`laurl`,'') AS `cat3url`,`f`.`id` AS `factorid`,`f`.`latitle` AS `factorname`,`f`.`laurl` AS `factorurl`,(`p`.`laoldprice` - `p`.`laprice`) AS `pricechange`,(select sum(`i`.`amount`) from `laorderitems` `i` where ((`i`.`product_id` = `p`.`id`) or (`i`.`variantid` = `p`.`id`))) AS `numorder` from ((((`laproducts` `p` left join `lamanufactors` `f` on((`f`.`id` = `p`.`lamanufactor_id`))) left join `lacategories` `c1` on((`c1`.`id` = `p`.`lacategory_id`))) left join `lacategories` `c2` on((`c1`.`laparent_id` = `c2`.`id`))) left join `lacategories` `c3` on((`c2`.`laparent_id` = `c3`.`id`))) where (((`p`.`ladeleted` <> 1) or isnull(`p`.`ladeleted`)) and (`p`.`lavariant_id` = 0));

/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
